
from time import sleep

from appium import webdriver
import logging

from appium.webdriver.common.multi_action import MultiAction
from appium.webdriver.common.touch_action import TouchAction

def test_function(remote_addr='http://localhost:4723/wd/hub', desired_caps=None, write_name="default"):
    if desired_caps is None:
        desired_caps = {}
        desired_caps['platformName'] = 'Android'
        desired_caps['platformVersion'] = '9'
        desired_caps['deviceName'] = 'emulator-5554'
        desired_caps['appPackage'] = 'de.danoeh.antennapod'
        desired_caps['appActivity'] = 'de.danoeh.antennapod.activity.SplashActivity'
        desired_caps['eventTimings'] = True
        #desired_caps['app'] = '/Users/evanna/Desktop/lizi/app-free-release-signed.apk'
        logging.info("logging app...")

    driver = webdriver.Remote(remote_addr, desired_caps)
    
    # test begin ---------------------------------
	sleep(1)
	driver.find_element_by_id('de.danoeh.antennapod:id/discover_more').click()
	sleep(1)
	driver.find_element_by_id('de.danoeh.antennapod:id/discover_more').click()
	sleep(1)
	driver.find_element_by_id('de.danoeh.antennapod:id/action_search').click()
	sleep(1)
	driver.find_element_by_id('de.danoeh.antennapod:id/imgvCover').click()
	sleep(1)
	sleep(1)
	sleep(1)
	sleep(1)
	driver.find_element_by_id('de.danoeh.antennapod:id/txtvTitle').click()
	sleep(1)
	driver.find_element_by_id('de.danoeh.antennapod:id/txtvDescription').click()
	sleep(1)
	select_element = driver.find_element_by_id('de.danoeh.antennapod:id/listview')
	element_size_width = select_element.size['width']
	element_size_height = select_element.size['height']
	element_location_x = select_element.location['x']
	element_location_y = select_element.location['y']
	driver.swipe(element_location_x+element_size_width*(1/4), element_location_y+element_size_height/2,element_location_x+element_size_width*(3/4), element_location_y+element_size_height/2, 1000)
	sleep(1)
	driver.find_element_by_id('de.danoeh.antennapod:id/txtvTitle').click()
	sleep(1)
	driver.find_element_by_id('de.danoeh.antennapod:id/txtvTitle').click()
	sleep(1)
	driver.press_keycode(25)
	sleep(1)
	driver.find_element_by_id('de.danoeh.antennapod:id/txtvDescription').click()
	sleep(1)
	driver.find_element_by_id('de.danoeh.antennapod:id/txtvDescription').click()
	sleep(1)
	driver.find_element_by_id('de.danoeh.antennapod:id/butSubscribe').click()
	sleep(1)
	driver.find_element_by_id('de.danoeh.antennapod:id/txtvTitle').click()
	sleep(1)
	driver.press_keycode(82)
	sleep(1)
	driver.find_element_by_id('de.danoeh.antennapod:id/txtvDescription').click()
	sleep(1)
	select_element = driver.find_element_by_id('android:id/list')
	element_size_width = select_element.size['width']
	element_size_height = select_element.size['height']
	element_location_x = select_element.location['x']
	element_location_y = select_element.location['y']
	driver.swipe(element_location_x+element_size_width/2, element_location_y+element_size_height*(3/4),element_location_x+element_size_width/2, element_location_y+element_size_height*(1/4), 1000)
	sleep(1)
	driver.find_element_by_id('de.danoeh.antennapod:id/secondaryActionButton').click()
	sleep(1)
	driver.find_element_by_id('de.danoeh.antennapod:id/secondaryActionButton').click()
	sleep(1)
	width = driver.get_window_size()['width']
	height = driver.get_window_size()['height']
	action1 = TouchAction(driver).press(el=None, x=width * 0.2, y=height * 0.2).wait(1000).move_to(el=None,x=width * 0.4,y=height * 0.4).release()
	action2 = TouchAction(driver).press(el=None, x=width * 0.8, y=height * 0.8).wait(1000).move_to(el=None,x=width * 0.6,y=height * 0.6).release()
	pinch_action = MultiAction(driver)
	pinch_action.add(action1, action2)
	pinch_action.perform()
	sleep(1)
	driver.find_element_by_id('android:id/content').click()
	sleep(1)
	driver.find_element_by_id('de.danoeh.antennapod:id/container').click()
	sleep(1)
	width = driver.get_window_size()['width']
	height = driver.get_window_size()['height']
	action1 = TouchAction(driver).press(el=None, x=width * 0.2, y=height * 0.2).wait(1000).move_to(el=None,x=width * 0.4,y=height * 0.4).release()
	action2 = TouchAction(driver).press(el=None, x=width * 0.8, y=height * 0.8).wait(1000).move_to(el=None,x=width * 0.6,y=height * 0.6).release()
	pinch_action = MultiAction(driver)
	pinch_action.add(action1, action2)
	pinch_action.perform()
	sleep(1)
	driver.find_element_by_id('de.danoeh.antennapod:id/butAction2').click()
	sleep(1)
	driver.press_keycode(4)
	sleep(1)
	driver.find_element_by_id('de.danoeh.antennapod:id/secondaryActionButton').click()
	sleep(1)
	driver.find_element_by_id('de.danoeh.antennapod:id/container').click()
	sleep(1)
	sleep(1)
	driver.find_element_by_id('de.danoeh.antennapod:id/txtvPodcast').click()
	sleep(1)
	driver.find_element_by_id('de.danoeh.antennapod:id/butShowSettings').click()
	sleep(1)
	driver.find_element_by_id('de.danoeh.antennapod:id/icon_frame').click()
	sleep(1)
	sleep(1)
	driver.find_element_by_id('de.danoeh.antennapod:id/fragmentLayout').click()
	sleep(1)
	driver.find_element_by_id('de.danoeh.antennapod:id/set_sleeptimer_item').click()
	sleep(1)
	driver.find_element_by_id('de.danoeh.antennapod:id/cbShakeToReset').click()
	sleep(1)
	width = driver.get_window_size()['width']
	height = driver.get_window_size()['height']
	action1 = TouchAction(driver).press(el=None, x=width * 0.4, y=height * 0.4).wait(1000).move_to(el=None,x=width * 0.2,y=height * 0.2).release()
	action2 = TouchAction(driver).press(el=None, x=width * 0.6, y=height * 0.6).wait(1000).move_to(el=None,x=width * 0.8,y=height * 0.8).release()
	pinch_action = MultiAction(driver)
	pinch_action.add(action1, action2)
	pinch_action.perform()
	sleep(1)
	driver.find_element_by_id('de.danoeh.antennapod:id/cbVibrate').click()
	sleep(1)
	driver.find_element_by_id('android:id/button1').click()
	sleep(1)
	driver.find_element_by_id('de.danoeh.antennapod:id/audio_controls').click()
	sleep(1)
	driver.find_element_by_id('de.danoeh.antennapod:id/butDecSpeed').click()
	sleep(1)
	driver.find_element_by_id('de.danoeh.antennapod:id/stereo_to_mono').click()
	sleep(1)
	driver.find_element_by_id('android:id/button1').click()
	sleep(1)
	driver.find_element_by_id('de.danoeh.antennapod:id/add_to_favorites_item').click()
	sleep(1)
	driver.find_element_by_id('de.danoeh.antennapod:id/butSkip').click()
	sleep(1)
	driver.find_element_by_id('android:id/title').click()
	sleep(1)
	driver.find_element_by_id('de.danoeh.antennapod:id/icon_frame').click()
	sleep(1)
	driver.find_element_by_id('android:id/switch_widget').click()
	sleep(1)
	driver.press_keycode(24)
	sleep(1)
	driver.find_element_by_id('de.danoeh.antennapod:id/icon_frame').click()
	sleep(1)
	driver.find_element_by_id('de.danoeh.antennapod:id/icon_frame').click()
	sleep(1)
	driver.find_element_by_id('android:id/title').click()
	sleep(1)
	sleep(1)
	sleep(1)
	sleep(1)
	select_element = driver.find_element_by_id('de.danoeh.antennapod:id/viewpager')
	element_size_width = select_element.size['width']
	element_size_height = select_element.size['height']
	element_location_x = select_element.location['x']
	element_location_y = select_element.location['y']
	driver.swipe(element_location_x+element_size_width*(1/4), element_location_y+element_size_height/2,element_location_x+element_size_width*(3/4), element_location_y+element_size_height/2, 1000)
	sleep(1)
	sleep(1)
	sleep(1)
	sleep(1)
	sleep(1)
	sleep(1)
	sleep(1)
	sleep(1)
	driver.press_keycode(82)
	sleep(1)
	sleep(1)
	sleep(1)
	driver.press_keycode(25)
	sleep(1)
	sleep(1)
	sleep(1)
	sleep(1)
	select_element = driver.find_element_by_id('de.danoeh.antennapod:id/viewpager')
	element_size_width = select_element.size['width']
	element_size_height = select_element.size['height']
	element_location_x = select_element.location['x']
	element_location_y = select_element.location['y']
	driver.swipe(element_location_x + element_size_width*(3/4), element_location_y + element_size_height/2,element_location_x + element_size_width*(1/4), element_location_y + element_size_height/2, 1000)
	sleep(1)
	sleep(1)
	sleep(1)
	sleep(1)
	sleep(1)
	sleep(1)
	sleep(1)
	sleep(1)
	sleep(1)
	driver.press_keycode(82)
	sleep(1)
	driver.press_keycode(25)
	sleep(1)
	driver.press_keycode(4)
	sleep(1)
	driver.press_keycode(4)
	sleep(1)


    # test end ------------------------------------
    # get the last page source
    page_source = driver.page_source
    print("{*} page_source get, len", len(page_source))
    with open(f"page_source_{write_name}.xml","w",encoding="utf8") as f:
        f.write(page_source)
